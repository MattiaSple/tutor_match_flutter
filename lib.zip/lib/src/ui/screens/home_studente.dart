import 'package:flutter/material.dart';

class HomeStudente extends StatelessWidget {
  final String userId;
  final bool ruolo;  // Puoi anche usare 'isTutor' se preferisci

  const HomeStudente({required this.userId, required this.ruolo, super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home Studente'),
      ),
      body: Center(
        child: Text(
          'Benvenuto nella Home Studente\nUserID: $userId\nRuolo: ${ruolo ? "Tutor" : "Studente"}',
          style: const TextStyle(fontSize: 24),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
