import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tutormatch/src/viewmodels/annuncio_view_model.dart';

class HomeTutor extends StatefulWidget {
  final String userId;
  final bool ruolo;

  const HomeTutor({required this.userId, required this.ruolo, super.key});

  @override
  _HomeTutorState createState() => _HomeTutorState();
}

class _HomeTutorState extends State<HomeTutor> {
  String? selectedMateria;
  List<String> materie = ['Matematica', 'Fisica', 'Informatica'];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    // Chiama la funzione per recuperare gli annunci dell'utente
    final annuncioViewModel = Provider.of<AnnuncioViewModel>(context, listen: false);
    annuncioViewModel.getAnnunciByUserId(widget.userId);
  }

  // Funzione per creare l'annuncio
  void _creaAnnuncio(AnnuncioViewModel annuncioViewModel) {
    if (selectedMateria != null) {
      annuncioViewModel.creaAnnuncio(widget.userId, selectedMateria!);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Annuncio creato con successo per materia: $selectedMateria')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seleziona una materia')),
      );
    }
  }

  // Funzione per eliminare un annuncio
  void _eliminaAnnuncio(String annuncioId, AnnuncioViewModel annuncioViewModel) {
    annuncioViewModel.eliminaAnnuncio(annuncioId);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Annuncio eliminato con successo')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final annuncioViewModel = Provider.of<AnnuncioViewModel>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Home Tutor'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Container(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.8, // Define max height
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButton<String>(
                hint: const Text('Seleziona una materia'),
                value: selectedMateria,
                onChanged: (String? newValue) {
                  setState(() {
                    selectedMateria = newValue;
                  });
                },
                items: materie.map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              ElevatedButton(
                onPressed: () => _creaAnnuncio(annuncioViewModel),
                child: const Text('Crea Annuncio'),
              ),
              Flexible(
                fit: FlexFit.loose,
                child: ListView.builder(
                  itemCount: annuncioViewModel.annunci.length,
                  itemBuilder: (context, index) {
                    final annuncio = annuncioViewModel.annunci[index];
                    return ListTile(
                      title: Text(annuncio['materia']),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () {
                          _eliminaAnnuncio(annuncio["id"], annuncioViewModel);
                        },
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
